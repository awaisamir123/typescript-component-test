import React from 'react';

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Menu from './components/Menu';

function App() {
  return (
    <div>
      <Menu />
    </div>
  );
}

export default App;
